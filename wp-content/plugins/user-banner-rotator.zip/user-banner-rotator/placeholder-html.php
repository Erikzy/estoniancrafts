<?php
/*
 
 	Html template
 */

wp_enqueue_style('main-styles', plugins_url().'/user-banner-rotator/assets/css/user-banner-rotator.css' );

wp_register_style( 'font-awe', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css' );
wp_enqueue_style('font-awe');



?>

<div class='placeholder center-block '>






</div>

